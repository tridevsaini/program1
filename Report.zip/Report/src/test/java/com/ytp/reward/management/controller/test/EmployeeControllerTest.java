package com.ytp.reward.management.controller.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import com.ytp.reward.management.report.controller.EmployeeController;
import com.ytp.reward.management.report.model.Employee;
import com.ytp.reward.management.report.repository.EmployeeRepository;

@RunWith(SpringRunner.class)
@SpringBootConfiguration
public class EmployeeControllerTest {

	@Mock
	private EmployeeRepository employeeRepository;
	
	@InjectMocks
	private EmployeeController employeeController;
	
	@Test
	public void testgetEmployee() {
	Employee employee = new Employee();
	employee.setEmpNo(1);
	employee.setFirstName("Ranshu");
	employee.setLastName("Saini");
	employee.setAddress("Hyderabad");
	employee.setContact1(3113213);
	employee.setContact2(433535);
	employee.setDesignation("IT");
	employee.setEmailId("saini@abc.com");
	employee.setGender("Male");
	employee.setWorklocation("Hyd");
	Mockito.when(employeeRepository.save(
	Mockito.any(Employee.class))).thenReturn(employee);
	employeeController.getEmployeebyId(2);
	}
	

	
	@Test
	public void getAllEmployeeTest() {
		Employee employee = new Employee();

		employee.setEmpNo(1);
		employee.setFirstName("Ranshu");
		employee.setLastName("Saini");
		employee.setAddress("Hyderabad");
		employee.setContact1(3113213);
		employee.setContact2(433535);
		employee.setDesignation("IT");
		employee.setEmailId("saini@abc.com");
		employee.setGender("Male");
		employee.setWorklocation("Hyd");
		Mockito.when(employeeRepository.save(
		Mockito.any(Employee.class))).thenReturn(employee);
		Pageable pageable = new Pageable() {

		@Override
		public Pageable previousOrFirst() {
		// TODO Auto-generated method stub
		return null;
		}

		@Override
		public Pageable next() {
		// TODO Auto-generated method stub
		return null;
		}

		@Override
		public boolean hasPrevious() {
		// TODO Auto-generated method stub
		return false;
		}

		@Override
		public Sort getSort() {
		// TODO Auto-generated method stub
		return null;
		}

		@Override
		public int getPageSize() {
		// TODO Auto-generated method stub
		return 0;
		}

		@Override
		public int getPageNumber() {
		// TODO Auto-generated method stub
		return 0;
		}

		@Override
		public long getOffset() {
		// TODO Auto-generated method stub
		return 0;
		}

		@Override
		public Pageable first() {
		// TODO Auto-generated method stub
		return null;
		}
		};

		employeeController.listAll(0, 5, 1);
		}
	
	
	}

