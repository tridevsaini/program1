/**
 * This package is regarding the exception.
 */
package com.ytp.reward.management.report.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

/**
* This is used for declare, resourceName.
*/
private String resourceName;
/**
* This is used for declare, fieldName.
*/

private String fieldName;
/**
* This is used for declare, fieldValue.
*/

private Object fieldValue;
/**
 * @param resourcename
 * @param fieldname
 * @param fieldvalue
 */
public ResourceNotFoundException(final String resourcename,
final String fieldname,
final Object fieldvalue) {
super(String.format("%s not found with %s : '%s'",
resourcename, fieldname, fieldvalue));
this.resourceName = resourcename;
this.fieldName = fieldname;
this.fieldValue = fieldvalue;
}

/**
 * This is getter for getResourceName.
 *
 * @return r
 */
public final String getResourceName() {
return resourceName;
}
/**
 * This is getter for getFieldName.
 *
 * @return r
 */
public final String getFieldName() {
return fieldName;
}
/**
 * This is getter for getFieldValue.
 *
 * @return r
 */
public final Object getFieldValue() {
return fieldValue;
}
}
