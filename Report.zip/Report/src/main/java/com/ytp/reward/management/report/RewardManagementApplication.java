/**
 * Info about this package doing something for package-info.java file.
 */
package com.ytp.reward.management.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class RewardManagementApplication {

/**
* This is main method.
* @param args
 */
 public static void main(final String[] args) {
SpringApplication.run(RewardManagementApplication.class, args);

}
}
