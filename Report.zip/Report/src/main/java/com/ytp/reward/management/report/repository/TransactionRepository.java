/**
 * Information about transaction repository.
 */
package com.ytp.reward.management.report.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ytp.reward.management.report.model.Transaction;

public interface TransactionRepository
extends JpaRepository<Transaction, Integer> {

/**
 * This query for getting employee information based on last week.
 * @param empId
 * @return this
 */
@Query(value = "select  t.temp_id,t.emp_id,sum(t.point) as point,"
+ "t.received_date\n"
+ "from transaction t\n"
+ "WHERE t.received_date>= CURDATE() -INTERVAL 6 DAY and t.emp_id= :emp_id\n"
+ "group by day(t.received_date) order by t.received_date", nativeQuery = true)

List<Transaction> gettransactionById(@Param("emp_id") Integer empId);

/**
 * This query for getting employee information based on last month.
 * @param empId
 * @return this
 */
@Query(value  = "SELECT  t.temp_id,t.received_date,"
+  " SUM(t.point) AS point,{fn monthname(t.received_date)} AS month\n"
+ "FROM   transaction t\n"
+ "WHERE  t.received_date <= CURDATE()+1  AND "
+ "t.received_date >= DATE_ADD(CURDATE()+1,"
+ " INTERVAL - 12 MONTH) and t.emp_id= :emp_id\n"
+ "GROUP BY DATE_FORMAT(t.received_date, '%m-%Y')"
+ " order by t.received_date", nativeQuery = true)

List<Transaction> getTransactionByMonthlyId(@Param("emp_id") Integer empId);

/**
 * This query for getting employee information based on last year.
 * @param empId
 * @return this
 */
@Query(value = " SELECT  t.temp_id,t.received_date,"
+ " SUM(t.point) AS point\n"
+ "FROM  transaction t\n"
+ "WHERE  t.received_date <= CURDATE()+1  "
+ "AND t.received_date >= DATE_ADD(CURDATE(),"
+ " INTERVAL - 5 YEAR) AND emp_id = :emp_id\n"
+ "GROUP BY DATE_FORMAT(t.received_date, '%Y')", nativeQuery = true)

List<Transaction> getTransactionByYearlyId(@Param("emp_id") Integer empId);

}
