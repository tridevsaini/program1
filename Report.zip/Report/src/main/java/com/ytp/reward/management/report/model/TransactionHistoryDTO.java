package com.ytp.reward.management.report.model;

import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName("transaction")
public class TransactionHistoryDTO {

/**
 * This is used for declare, point.
 */
private int points;
/**
 * This is used for declare, receivedDate.
 */
private String receivedDate;

/**
 * This is getter for temp_id.
 *
 * @return r
 */
public int getPoints() {
return points;
}
/**
* This is setter for points.
*
* @param pointsw
*/
public void setPoints(final int pointsw) {
this.points = pointsw;
}
/**
 * This is getter for receivedDate.
 *
 * @return receivedDate
 */
public String getReceivedDate() {
return receivedDate;
}
/**
* This is setter for receivedDate.
*
* @param receivedDatew
*/
public void setReceivedDate(final String receivedDatew) {
this.receivedDate = receivedDatew;
}

}
