package com.ytp.reward.management.report.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ytp.reward.management.report.model.Employee;
import com.ytp.reward.management.report.model.EmployeeListDTO;
import com.ytp.reward.management.report.model.Transaction;
import com.ytp.reward.management.report.model.TransactionDTO;
import com.ytp.reward.management.report.model.TransactionHistoryDTO;
import com.ytp.reward.management.report.repository.EmployeeRepository;
import com.ytp.reward.management.report.repository.TransactionRepository;


@RestController
@RequestMapping("RewardsManagement/home")
public class EmployeeController {
/**
 * This Autowired the EmployeeRepository.
 */
    @Autowired
     private EmployeeRepository employeeRepository;

    /**
     * This autowired the TransactionRepository.
     */
    @Autowired
    private TransactionRepository transactionepository;

/**
 *
 * @param empId
 * @return employee.
 */
@GetMapping("/employee/week/{id}")
public TransactionDTO getEmployeebyId(
@PathVariable(value = "id") final Integer empId) {
TransactionDTO transactionDTO = new TransactionDTO();
List<Transaction> transactionsList = new ArrayList<Transaction>();
List<TransactionHistoryDTO> transactionHDTOList = new ArrayList<>();
TransactionHistoryDTO transactionHistoryDTO = null;
String dayPattern = "EEEE";
SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dayPattern);
Employee employee = null;
System.out.println();
try {
transactionsList = transactionepository.gettransactionById(empId);

for (Transaction transaction : transactionsList) {
System.out.println(transaction.getReceivedDate());
transactionHistoryDTO = new TransactionHistoryDTO();
transactionHistoryDTO.setReceivedDate(simpleDateFormat.format(transaction
.getReceivedDate()));
                transactionHistoryDTO.setPoints(transaction.getPoint());
                transactionHDTOList.add(transactionHistoryDTO);
System.out.println(transactionHistoryDTO.getReceivedDate()
+ "-----------" + transactionHistoryDTO.getPoints());
}
if (transactionHDTOList.size() > 0) {
transactionDTO.setTransactionHistoryDTOs(transactionHDTOList);
}

employee = new Employee();
employee = employeeRepository.getOne(empId);
if (employee != null) {
transactionDTO.setEmpId(employee.getEmpId());
transactionDTO.setEmailId(employee.getEmailId());
transactionDTO.setFirstName(employee.getFirstName());
transactionDTO.setLastName(employee.getLastName());
transactionDTO.setAddress(employee.getAddress());
transactionDTO.setEmpNo(employee.getEmpNo());
transactionDTO.setContact1(employee.getContact1());
transactionDTO.setContact2(employee.getContact2());
transactionDTO.setDesignation(employee.getDesignation());
transactionDTO.setGender(employee.getGender());
transactionDTO.setWorklocation(employee.getWorklocation());

}

} catch (Exception e) {
e.printStackTrace();
}
return transactionDTO;
    }
/**
*
* @param empId
* @return employee.
*/
@GetMapping("/employee/month/{id}")
public TransactionDTO  getEmployeeMonthId(@PathVariable(value = "id") final
Integer empId) {
TransactionDTO transactionDTO = new TransactionDTO();
List<Transaction> transactionsList = new ArrayList<Transaction>();
List<TransactionHistoryDTO> transactionHDTOList = new ArrayList<>();
TransactionHistoryDTO transactionHistoryDTO = null;
String monthPattern = "MMMMM";
SimpleDateFormat simpleDateFormat = new SimpleDateFormat(monthPattern);
Employee employee = null;
try {
transactionsList = transactionepository.getTransactionByMonthlyId(empId);
for (Transaction transaction : transactionsList) {
transactionHistoryDTO = new TransactionHistoryDTO();
transactionHistoryDTO.setReceivedDate(simpleDateFormat.format(
transaction.getReceivedDate()));
transactionHistoryDTO.setPoints(transaction.getPoint());
transactionHDTOList.add(transactionHistoryDTO);
System.out.println(transactionHistoryDTO.getReceivedDate()
+ "-----------" + transactionHistoryDTO.getPoints());
}
if (transactionHDTOList.size() > 0) {
transactionDTO.setTransactionHistoryDTOs(transactionHDTOList);
}
employee  = new Employee();
employee =  employeeRepository.getOne(empId);
if (employee != null) {
transactionDTO.setEmpId(employee.getEmpId());
 transactionDTO.setEmailId(employee.getEmailId());
  transactionDTO.setFirstName(employee.getFirstName());
  transactionDTO.setLastName(employee.getLastName());
  transactionDTO.setAddress(employee.getAddress());
  transactionDTO.setEmpNo(employee.getEmpNo());
 transactionDTO.setContact1(employee.getContact1());
  transactionDTO.setContact2(employee.getContact2());
  transactionDTO.setDesignation(employee.getDesignation());
  transactionDTO.setGender(employee.getGender());
transactionDTO.setWorklocation(employee.getWorklocation());
}

} catch (Exception e) {
e.printStackTrace();
}
return transactionDTO;
    }

/**
*
* @param empId
* @return employee.
*/
    @GetMapping("/employee/year/{id}")
public TransactionDTO  getEmployeeYearId(@PathVariable(
value = "id") final Integer empId) {
TransactionDTO transactionDTO = new TransactionDTO();
List<Transaction> transactionsList = new ArrayList<Transaction>();
List<TransactionHistoryDTO> transactionHDTOList = new ArrayList<>();
TransactionHistoryDTO transactionHistoryDTO = null;
String yearPattern = "YYYY";
SimpleDateFormat simpleDateFormat = new SimpleDateFormat(yearPattern);
Employee employee = null;
try {
transactionsList = transactionepository.getTransactionByYearlyId(empId);
for (Transaction transaction : transactionsList) {
transactionHistoryDTO = new TransactionHistoryDTO();
transactionHistoryDTO.setReceivedDate(simpleDateFormat.format(
transaction.getReceivedDate()));
                transactionHistoryDTO.setPoints(transaction.getPoint());
                transactionHDTOList.add(transactionHistoryDTO);

}
if (transactionHDTOList.size() > 0) {
transactionDTO.setTransactionHistoryDTOs(transactionHDTOList);
}

employee = new Employee();
employee = employeeRepository.getOne(empId);
if (employee != null) {
transactionDTO.setEmpId(employee.getEmpId());
transactionDTO.setEmailId(employee.getEmailId());
transactionDTO.setFirstName(employee.getFirstName());
transactionDTO.setLastName(employee.getLastName());
transactionDTO.setAddress(employee.getAddress());
transactionDTO.setEmpNo(employee.getEmpNo());
transactionDTO.setContact1(employee.getContact1());
transactionDTO.setContact2(employee.getContact2());
transactionDTO.setDesignation(employee.getDesignation());
transactionDTO.setGender(employee.getGender());
transactionDTO.setWorklocation(employee.getWorklocation());
}

} catch (Exception e) {
e.printStackTrace();
}
return transactionDTO;
    }

    /**
    *
    * @param pageNo
    * @param pageSize
    * @param empNo
    * @return employee.
    */

@GetMapping("/employees")
public List<EmployeeListDTO> listAll(final Integer pageNo,
final Integer pageSize, final Integer empNo) {
Pageable paging =
PageRequest.of(pageNo, pageSize, Sort.by("empNo").ascending());
EmployeeListDTO employeeListDTO = null;
List<EmployeeListDTO> employeeListDTOs = new ArrayList<EmployeeListDTO>();

Page<Employee>  employees =  null;
try {
employees = employeeRepository.findAll(paging);
if (employees.getSize() > 0) {
for (Employee employee2 : employees) {
employeeListDTO = new EmployeeListDTO();
employeeListDTO.setEmpNo(employee2.getEmpNo());
employeeListDTO.setFirstName(employee2.getFirstName());
employeeListDTO.setLastName(employee2.getLastName());
employeeListDTO.setEmailId(employee2.getEmailId());
employeeListDTOs.add(employeeListDTO);
}
}

} catch (Exception e) {
e.printStackTrace();
}
return employeeListDTOs;
    }

}
