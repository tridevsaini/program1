package com.ytp.reward.management.report.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "transaction")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties({ "temp_id" })
public class Transaction {
/**
* This is used for declare, employee id.
*/
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private int temp_id;

/**
 * This is used for declare, point.
 */
@NotBlank

private int point;

/**
 * This is used for declare, receivedDate.
 */
@Temporal(TemporalType.TIMESTAMP)

private Date receivedDate;

/**
 * This is getter for temp_id.
 *
 * @return r
 */
public int getTemp_id() {
return temp_id;
}
/**
* This is setter for tempId.
*
*/
public void setTemp_id(final int temp_idw) {
this.temp_id = temp_idw;
}

/**
 * This is getter for point.
 *
 * @return r
 */
public int getPoint() {
return point;
}
/**
* This is setter for point.
*
* @param pointw
*/
public void setPoint(final int pointw) {
this.point = pointw;
}

/**
 * This is getter for receivedDate.
 *
 * @return r
 */
public Date getReceivedDate() {
return receivedDate;
}
/**
* This is setter for receivedDate.
*
* @param receivedDatew
*/
public void setReceivedDate(final Date receivedDatew) {
this.receivedDate = receivedDatew;
}

}
