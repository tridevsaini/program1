package com.ytp.reward.management.report.model;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonProperty;

public class TransactionDTO {

/**
*This is used for declare, employee id.
*/
private int empId;
/**
 * This is used for declare, firstName.
  */
private String firstName;
/**
 * This is used for declare, lastName.
 */
private String lastName;
/**
 * This is used for declare, emailId.
 */
private String emailId;
/**
 * This is used for declare,
 *  address.
 */
private String address;
/**
 * This is used for declare, empNo.
 */
private int empNo;
/**
 * This is used for declare, contact1.
  */
private long contact1;
/**
 * This is used for declare, contact2.
 */
private long contact2;
/**
 * This is used for declare, designation.
 */
private String designation;
/**
 * This is used for declare, gender.
 */
private String gender;
/**
 * This is used for declare, worklocation.
 */
private String worklocation;

/**
 * This is used for setting json property.
 */
@JsonProperty("transaction")
private List<TransactionHistoryDTO> transactionHistoryDTOs;

/**
 * This is getter for employee id.
 *
 * @return r
 */
public int getEmpId() {
return empId;
}
/**
* This is setter for empId.
*
* @param empIdw
*/
public void setEmpId(final int empIdw) {
this.empId = empIdw;
}
/**
 * This is getter for employee id.
 *
 * @return r
 */
public String getFirstName() {
return firstName;
}
/**
 * @param firstNamew
 */
public void setFirstName(final String firstNamew) {
this.firstName = firstNamew;
}
/**
* This is getter for lastName.
*
 * @return r
*/
public String getLastName() {
return lastName;
}
/**
* This is setter for lastName.
*
* @param lastNamew
*/
public void setLastName(final String lastNamew) {
this.lastName = lastNamew;
}
/**
* This is getter for emailId.
*
* @return r
*/
public String getEmailId() {
return emailId;
}
/**
* This is setter for emailId.
*
* @param emailIdw
*/
public void setEmailId(final String emailIdw) {
this.emailId = emailIdw;
}
/**
* This is getter for address.
*
* @return r
*/
public String getAddress() {
return address;
}
/**
* This is setter for addressw.
*
* @param addressw
*/
public void setAddress(final String addressw) {
this.address = addressw;
}
/**
* This is getter for transaction.
*
* @return r
*/
public List<TransactionHistoryDTO> getTransactionHistoryDTOs() {
return transactionHistoryDTOs;
}
/**
* This is setter for transaction.
*
* @param transactionHistoryDTOsw
*/
public void setTransactionHistoryDTOs(final
List<TransactionHistoryDTO> transactionHistoryDTOsw) {
this.transactionHistoryDTOs = transactionHistoryDTOsw;
}
/**
* This is getter for empNo.
*
* @return r
*/
public int getEmpNo() {
return empNo;
}
/**
* This is setter for empNo.
*
* @param empNow
*/
public void setEmpNo(final int empNow) {
this.empNo = empNow;
}
/**
* This is getter for contact1.
*
* @return r
*/
public long getContact1() {
return contact1;
}
/**
* This is setter for contact1.
*
* @param contact1w
*/
public void setContact1(final long contact1w) {
this.contact1 = contact1w;
}
/**
* This is getter for contact2.
*
* @return r
*/
public long getContact2() {
return contact2;
}
/**
* This is setter for contact2.
*
* @param contact2w
*/
public void setContact2(final long contact2w) {
this.contact2 = contact2w;
}
/**
* This is getter for designation.
*
* @return r
*/
public String getDesignation() {
return designation;
}
/**
* This is setter for designation.
*
* @param designationw
*/
public void setDesignation(final String designationw) {
this.designation = designationw;
}
/**
* This is getter for gender.
*
* @return r
*/
public String getGender() {
return gender;
}
/**
* This is setter for gender.
*
* @param genderw
*/
public void setGender(final String genderw) {
this.gender = genderw;
}
/**
* This is getter for worklocation.
*
* @return r
*/
public String getWorklocation() {
return worklocation;
}
/**
* This is setter for worklocation.
*
* @param worklocationw
*/
public void setWorklocation(final String worklocationw) {
this.worklocation = worklocationw;
}


}
