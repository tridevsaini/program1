package com.ytp.reward.management.report.model;

public class EmployeeListDTO {
/**
* This is used for declare, employee id.
*/
private int empNo;
/**
 * This is used for declare, firstName.
  */
private String firstName;
/**
 * This is used for declare, lastName.
 */
private String lastName;
/**
 * This is used for declare, emailId.
 */
private String emailId;

/**
* This is getter for empNo.
*
* @return r
*/
public int getEmpNo() {
return empNo;
}
/**
* This is setter for empNo.
*
* @param empNow
*/
public void setEmpNo(final int empNow) {
this.empNo = empNow;
}
/**
 * This is getter for employee id.
 *
 * @return r
 */
public String getFirstName() {
return firstName;
}
/**
 * @param firstNamew
 */
public void setFirstName(final String firstNamew) {
this.firstName = firstNamew;
}
/**
 * This is getter for employee id.
 *
  * @return r
*/
public String getLastName() {
return lastName;
}
/**
* This is setter for lastName.
*
* @param lastNamew
*/
public void setLastName(final String lastNamew) {
this.lastName = lastNamew;
}
/**
* This is getter for employee id.
*
* @return r
*/
public String getEmailId() {
return emailId;
}
/**
* This is setter for emailId.
*
* @param emailIdw
*/
public void setEmailId(final String emailIdw) {
this.emailId = emailIdw;
}


}
