package com.ytp.ioc;

public class Zomato implements FoodOrder{

	public void order() {
		System.out.println("Order Placed in Zomato");
		
	}

	public void delivery() {
		System.out.println("Order Delivered to customer");
		
	}

}
