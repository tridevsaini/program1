package com.ytp.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerOrderedFood {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		FoodOrder foodorder = (FoodOrder) context. getBean("FoodOrder");
		foodorder.order();
		foodorder.delivery();

	}

}
