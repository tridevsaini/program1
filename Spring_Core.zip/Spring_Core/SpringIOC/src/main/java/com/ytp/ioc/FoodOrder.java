package com.ytp.ioc;

public interface FoodOrder {
	
	void order();
	void delivery();

}
