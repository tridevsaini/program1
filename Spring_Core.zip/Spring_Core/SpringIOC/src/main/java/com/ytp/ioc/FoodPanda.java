package com.ytp.ioc;

public class FoodPanda implements FoodOrder{

	public void order() {
		System.out.println("Order Placed in FoodPanda");
		
	}

	public void delivery() {
		System.out.println("Order Delivered to customer");
		
	}

}
