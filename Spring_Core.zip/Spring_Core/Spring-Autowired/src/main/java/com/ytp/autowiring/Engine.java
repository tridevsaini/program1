package com.ytp.autowiring;

public class Engine {
	
	public void engineStart() {
		System.out.println("Engine start");
	}

}
