package com.ytp.autowiring;

import org.springframework.beans.factory.annotation.Autowired;

public class Car {
	
	private Engine eng;
	@Autowired
	public Car(Engine eng) {
		this.eng = eng;
	}

	public void setEng(Engine eng) {
		this.eng = eng;
	}

	public void start() {
		if(eng!=null) {
			eng.engineStart();
		}
		else {
			System.out.println("Engine not started");
		}
		
	}

}
