package com.ytp.Service;

import java.util.List;

import com.ytp.model.Employee;

public interface EmployeeService {

	public void addEmployee(Employee employee);
	public Employee fetchEmployeeId(int id);
	public void deleteEmployeeId(int id);
	public void updateEmailId(String email, int id);
	public List<Employee> getAllEmployeeDetail();
}
