package com.ytp.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ytp.Service.EmployeeService;
import com.ytp.Service.EmployeeServiceImpl;
import com.ytp.model.Employee;

public class Test {

	public static void main(String[] args) {

		System.out.println("Run");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("Execute");
		EmployeeService empService = (EmployeeServiceImpl) ctx.getBean("employeeService");
		
		Employee employee = new Employee();
		employee.setId(10);
		employee.setName("Ranshu");
		employee.setAge(23);
		employee.setGender("Male");
		employee.setEmail("saini@ytp.com");
		employee.setSalary(2500);
		employee.setDepartment("IT");
		empService.addEmployee(employee);
		((ClassPathXmlApplicationContext)ctx).close();
	}

}
