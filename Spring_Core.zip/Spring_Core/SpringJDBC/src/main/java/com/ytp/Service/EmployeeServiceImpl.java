package com.ytp.Service;

import java.util.List;

import com.ytp.DAO.EmployeeDAO;
import com.ytp.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		
		this.employeeDAO = employeeDAO;
	}

	
	public void addEmployee(Employee employee) {
		
		employeeDAO.createEmployee(employee);
	}


	public Employee fetchEmployeeId(int id) {

		return employeeDAO.getEmployeeId(id);
	}


	public void deleteEmployeeId(int id) {
		
		employeeDAO.deleteEmployeeId(id);
	}


	public void updateEmailId(String email, int id) {
	
		employeeDAO.updateEmailId(email, id);
	}

	
	public List<Employee> getAllEmployeeDetail() {
		
		return employeeDAO.getAllDetail();
	}

}
