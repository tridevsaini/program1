package com.ytp.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import com.ytp.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	private DataSource ds;
	
	public void setDs(DataSource ds) {
		this.ds = ds;
	}
	

	public void createEmployee(Employee employee) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = ds.getConnection();
			String SQL = "INSERT INTO EMPLOYEE(empid, empname, empage, empgender, empemail, empsalary, empdepartment) VALUES(?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(SQL);
			
			ps.setInt(1, employee.getId());
			ps.setString(2, employee.getName());
			ps.setInt(3, employee.getAge());
			ps.setString(4, employee.getGender());
			ps.setString(5, employee.getEmail());
			ps.setInt(6, employee.getSalary());
			ps.setString(7, employee.getDepartment());
			int status = ps.executeUpdate();
			if(status>0) {
				System.out.println("Employee created");
			}
		}
		catch(Exception e) {
			
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	
	public Employee getEmployeeId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void deleteEmployeeId(int id) {
		// TODO Auto-generated method stub

	}


	public void updateEmailId(String email, int id) {
		// TODO Auto-generated method stub

	}

	
	public List<Employee> getAllDetail() {
		// TODO Auto-generated method stub
		return null;
	}

}
