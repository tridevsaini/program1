package com.ytp.DAO;

import java.util.List;

import com.ytp.model.Employee;

public interface EmployeeDAO {

	public void createEmployee(Employee employee);
	public Employee getEmployeeId(int id);
	public void deleteEmployeeId(int id);
	public void updateEmailId(String email, int id);
	public List<Employee> getAllDetail();
}
