package com.ytp.properties;

import org.springframework.beans.factory.annotation.Value;

public class Student {
	
	@Value("${student.name}")
	private String name;
	
	@Value("786")
	private int id;
	
	@Value("snooker")
	private String hobby;
	
	
	public void display() {
		System.out.println("Name:"+name);
		System.out.println("Id:"+id);
		System.out.println("hobby:"+hobby);
	}

}
