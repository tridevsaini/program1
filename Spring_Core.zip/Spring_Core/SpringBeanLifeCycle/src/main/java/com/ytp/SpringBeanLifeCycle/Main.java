package com.ytp.SpringBeanLifeCycle;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		StudentDAO std = (StudentDAO) ctx.getBean("studentDAO");
		std.selectRow();
//		((AbstractApplicationContext) ctx).close();
		((AbstractApplicationContext) ctx).registerShutdownHook();
	}

}
