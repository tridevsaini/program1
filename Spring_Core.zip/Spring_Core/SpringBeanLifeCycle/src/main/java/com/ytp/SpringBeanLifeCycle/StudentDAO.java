package com.ytp.SpringBeanLifeCycle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class StudentDAO {
	
	private String driver;
	private String url;
	private String user;
	private String pwd;
	Connection conn = null;
	
	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@PostConstruct
	public void init() throws SQLException, ClassNotFoundException{
		System.out.println("Inside the init method");
		createConnection();
	}
	public void createConnection() throws SQLException, ClassNotFoundException{
		
		Class.forName(driver);
		conn = DriverManager.getConnection(url ,user ,pwd);
		System.out.println("Connection Established");
		
	}
	public void selectRow() throws SQLException {
		
		Statement stmt = conn.createStatement();
		System.out.println("Query Executed");
		ResultSet rs = stmt.executeQuery("SELECT * FROM EMPLOYEE");
		
		while(rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString(2);
			int age = rs.getInt(3);
			String gender = rs.getString(4);
			String email = rs.getString(5);
			int salary = rs.getInt(6);
			String address = rs.getString(7);
			
			System.out.println(id+" "+name+" "+age+" "+gender+" "+email+" "+salary+" "+address);
		}
	}
	public void connectionClose() throws SQLException {
		conn.close();
	}
	@PreDestroy
	public void destroy() throws SQLException {
		System.out.println("Connection Closed");
		connectionClose();
	}

}
