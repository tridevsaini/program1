package com.ytp.report.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ytp.report.model.Employee;

@Repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {
	
	Employee findByUsername(String username);
}
