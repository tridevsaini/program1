package com.ytp.report.service;

import java.util.List;

import com.ytp.report.model.Employee;


public interface EmployeeService {

	List<Employee> findAll();
}
