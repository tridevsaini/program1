package com.ytp.rs.SpringbootCurd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCurdApplicationTests {

	@Test
	void contextLoads() {
	}

}
